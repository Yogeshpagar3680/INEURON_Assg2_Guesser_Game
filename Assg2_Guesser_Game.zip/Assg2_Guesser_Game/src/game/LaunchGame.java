package game;

import java.util.Scanner;

class Guesser
{
    int guessNumber;
    int range = 10;
    public int GuesserGuessNumber()
    {
        Scanner scan = new Scanner(System.in);

        System.out.println("Guesser kindly guess any number between 0 to " + range);
        guessNumber = scan.nextInt();
        if(guessNumber > range)
            System.out.println("Kindly enter the no from 0 to " + range);
        return guessNumber;
    }
}

class Player
{
    int pGuessNumber;
    int range2 = 10;
    public int playerGuessNumber()
    {
        Scanner scan = new Scanner(System.in);

        System.out.println("Player kindly guess any no between o to " + range2);
        pGuessNumber = scan.nextInt();
        if(pGuessNumber > 10)
            System.out.println("Kindly guess the no from 0 to " + range2);
        return pGuessNumber;
    }
}

class Umpire
{
    int numFromGuesser;
    int numFromPlayer1;
    int numFromPlayer2;
    int numFromPlayer3;

    public int collectNumFromGuesser()
    {
        Guesser guesser = new Guesser();
        numFromGuesser = guesser.GuesserGuessNumber();
        return numFromGuesser;
    }

    public void collectNumFromPlayer()
    {
        Player player1 = new Player();
        Player player2 = new Player();
        Player player3 = new Player();

        numFromPlayer1 = player1.playerGuessNumber();
        numFromPlayer2 = player2.playerGuessNumber();
        numFromPlayer3 = player3.playerGuessNumber();
    }

    public void compare()
    {
        if(numFromGuesser == numFromPlayer1)
        {
            if(numFromGuesser == numFromPlayer2 && numFromGuesser == numFromPlayer3)
            {
                System.out.println("Game tied! All three players guess correctly");
            }
            else if (numFromGuesser == numFromPlayer3)
            {
                System.out.println("Player 1 and Player 3 won the game!");
            }
            else if (numFromGuesser == numFromPlayer2)
            {
                System.out.println("Player 1 and player 2 won the game!");
            }
            else
            {
                System.out.println("Player 1 won the game!");
            }
        }
        else if (numFromGuesser == numFromPlayer2)
        {
            if (numFromGuesser == numFromPlayer3)
            {
                System.out.println("Player 2 and Player 3 won the game!");
            }
            else
            {
                System.out.println("Player 2 won the game!");
            }
        }
        else if (numFromGuesser == numFromPlayer3)
        {
            System.out.println("Player 3 won the game!");
        }
        else
        {
            System.out.println("Game lost! try again");
        }
    }
}

public class LaunchGame {
    public static void main(String[] args) {

        Umpire umpire = new Umpire();
        umpire.collectNumFromGuesser();
        umpire.collectNumFromPlayer();
        umpire.compare();

    }
}
